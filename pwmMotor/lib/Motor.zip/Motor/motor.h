#include<stm32f30x_gpio.h>
#include<stm32f30x_gpio.h>
#include<stm32f30x.h>
#include<stm32f30x_rcc.h>
#include<stm32f30x_tim.h>

#ifndef __MOTOR_H
#define __MOTOR_H
#endif

class Motor{
	private:
		GPIO_TypeDef* PwmGPIO[2] = {GPIOB,  GPIOB};
		GPIO_TypeDef* DirGPIO[2] = {GPIOB,  GPIOE};
		uint16_t dir[2] = {GPIO_Pin_11, GPIO_Pin_14};
		uint16_t pwm[2] = {GPIO_Pin_15, GPIO_Pin_13};


		// Check which value in GPIOE correspond to which light
		// intuitively RED should be stop and green cannot be error
		// Change if necessary
		enum statusLed {STOP=8, OK, ERROR};

	public:
		// Add timer array (of size 6) if multiple timers are used
		enum direction {STOP, FORWARD, RIGHT, BACKWARD, LEFT};
		// Initialization Functions
		void InitializeTimer();
		// Initialize all wheels in this function only
		// includeing gpio and pwm
		// use gpio.GPIO_Pin = GPIO_Pin_X | GPIO_Pin_X to initialize
		// multiple pins
		void intializeWheels();

		// Code accepts index for dir[] and pwm[]
		// as a param to control the wheel
		// implement this in one function only
		// Stop should set pwm as 0 and leave direction as is
		void controlWheel(const int index, const int speed, const int direct);

		// it accepts enum direction
		// use switch case to implement it
		void moveRover(const direction dir);

		// It should set all dir and pwm to 0
		void resetAll();

};
